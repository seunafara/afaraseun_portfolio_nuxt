<template>
  <div class="absolute flex flex-col w-1/5 min-h-full right-2 top-1">
    <div class="h-1/5 min-w-full text-gray-600 font-body font-extrabold">
      A
    </div>
    <div class="h-1/5 min-w-full text-gray-600 font-body font-extrabold">
      F
    </div>
    <div class="h-1/5 min-w-full text-gray-600 font-body font-extrabold">
      A
    </div>
    <div class="h-1/5 min-w-full text-gray-600 font-body font-extrabold">
      R
    </div>
    <div class="h-1/5 min-w-full text-gray-600 font-body font-extrabold">
      A
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
