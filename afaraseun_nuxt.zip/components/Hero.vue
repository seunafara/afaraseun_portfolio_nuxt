<template>
  <div
    class="as-bg as-container relative flex flex-col justify-between items-center py-14 px-4 rounded-lg md:flex-row md:px-8 lg:px-20 as-bg-margin"
  >
    <div>
      <h2 class="text-white text-3xl font-bold lg:text-5xl">Hi, I'm Seun</h2>
      <p class="text-white text-sm mt-2 font-sans lg:text-lg">
        A frontend developer in the day, a backend developer at night. I build
        amazing web applications for clients anywhere in the world. Scroll to
        see some projects done by me.
      </p>
    </div>
    <img
      class="md:w-2/4 lg:w-2/5"
      src="https://afaraseun.com/img/memoji_4.0f03c087.webp"
      alt=""
    />
  </div>
</template>

<script>
export default {};
</script>

<style></style>
