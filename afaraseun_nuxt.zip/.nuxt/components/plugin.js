import Vue from 'vue'

const components = {
  About: () => import('../..\\components\\About.vue' /* webpackChunkName: "components/about" */).then(c => c.default || c),
  Hero: () => import('../..\\components\\Hero.vue' /* webpackChunkName: "components/hero" */).then(c => c.default || c),
  Logo: () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => c.default || c),
  Name: () => import('../..\\components\\Name.vue' /* webpackChunkName: "components/name" */).then(c => c.default || c),
  Skills: () => import('../..\\components\\Skills.vue' /* webpackChunkName: "components/skills" */).then(c => c.default || c),
  Works: () => import('../..\\components\\Works.vue' /* webpackChunkName: "components/works" */).then(c => c.default || c)
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
