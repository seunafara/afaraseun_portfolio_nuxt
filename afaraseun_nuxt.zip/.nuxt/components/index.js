export { default as About } from '../..\\components\\About.vue'
export { default as Hero } from '../..\\components\\Hero.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Name } from '../..\\components\\Name.vue'
export { default as Skills } from '../..\\components\\Skills.vue'
export { default as Works } from '../..\\components\\Works.vue'

export const LazyAbout = import('../..\\components\\About.vue' /* webpackChunkName: "components/about" */).then(c => c.default || c)
export const LazyHero = import('../..\\components\\Hero.vue' /* webpackChunkName: "components/hero" */).then(c => c.default || c)
export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => c.default || c)
export const LazyName = import('../..\\components\\Name.vue' /* webpackChunkName: "components/name" */).then(c => c.default || c)
export const LazySkills = import('../..\\components\\Skills.vue' /* webpackChunkName: "components/skills" */).then(c => c.default || c)
export const LazyWorks = import('../..\\components\\Works.vue' /* webpackChunkName: "components/works" */).then(c => c.default || c)
